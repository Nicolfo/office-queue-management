package it.polito.se2.g04.officequeuemanagement;

import it.polito.se2.g04.officequeuemanagement.Services.Service;
import it.polito.se2.g04.officequeuemanagement.Tickets.Ticket;
import it.polito.se2.g04.officequeuemanagement.Counters.Counter;
import it.polito.se2.g04.officequeuemanagement.Tickets.TicketService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class CounterGetNextTicket {
    private final TicketService ticketService;
    @Autowired
    public CounterGetNextTicket (TicketService ticketService){
        this.ticketService=ticketService;
    }

    public Ticket getTicketToServe(Counter counter){
        List<Service> services= counter.getAssociated_services();
        Ticket ticket=ticketService.getNextTicketfromQueue(services);
        ticketService.setTicketCounter(ticket,counter);
        return ticket;
    }
}

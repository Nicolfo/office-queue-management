package it.polito.se2.g04.officequeuemanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OfficeQueueManagementApplication {

    public static void main(String[] args) {
        SpringApplication.run(OfficeQueueManagementApplication.class, args);
    }

}
